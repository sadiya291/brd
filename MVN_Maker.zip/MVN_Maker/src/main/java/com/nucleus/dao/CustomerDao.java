package com.nucleus.dao;

import java.util.List;

import com.nucleus.domain.Customer;

public interface CustomerDao 
{
	public void save(Customer customer);
	public void delete(String customercode);
	public List<Customer> show();
	public Customer showRecord(Customer customer);
	public Customer updateRecord(Customer customer);
}
