package com.nucleus.model.DAO;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.nucleus.model.Domain.Customer;



@Repository
public class CustomerDaoImpl implements CustomerDAO
{  
	@Autowired
    JdbcTemplate jdbcTemplate;
	long millis=System.currentTimeMillis();
	Date date=new Date(millis);
	@Override
	public void save(Customer customer) 
	{
		Object[] values={customer.getCustomer_Code(),customer.getCustomer_Name(),customer.getCustomer_Address1(),customer.getCustomer_Address2(),customer.getCustomer_Pincode(),customer.getEmail_address(),customer.getContact_Number(),customer.getPrimary_Contact_Person(),customer.getRecord_Status(),customer.getActive_Inactive_Flag(),date,"puja",customer.getModified_Date(),customer.getModified_By()};
		jdbcTemplate.update("insert into Main007 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",values);
		
	}
	public void delete(String Customer_Code)
	{
	
		jdbcTemplate.update("delete from Main007 where Customer_Code=?", Customer_Code);
	}
	
	
	public Customer view(String Customer_Code)
	{
		

		  String sql = "SELECT * FROM Main007 where  Customer_Code=?";
		
		  Object[] value={Customer_Code};
		
		  return jdbcTemplate.queryForObject(sql, value, new BeanPropertyRowMapper<Customer>(Customer.class));
	
	}
	//---------------------------
	public Customer update(Customer customer)
	{
		
		Object[] values={customer.getCustomer_Name(),customer.getCustomer_Address1(),customer.getCustomer_Address2(),customer.getCustomer_Pincode(),customer.getEmail_address(),customer.getContact_Number(),customer.getPrimary_Contact_Person(),customer.getRecord_Status(),customer.getActive_Inactive_Flag(),customer.getCustomer_Code()};
	
		jdbcTemplate.update("update table89 set Customer_Name=?, Customer_Address1=?, Customer_Address2=?,Customer_Pincode=?,Email_address=?, Contact_Number=?,Primary_Contact_Person=?,Record_Status=?,Active_Inactive_Flag=? where Customer_Code=?",values);
		return customer;
	}

	public Customer viewUpdate(String Customer_Code) 
	{

			  String sql = "SELECT * FROM table89 where  Customer_Code=?";
			
			  Object[] value={Customer_Code};
			  return jdbcTemplate.queryForObject(sql, value, new BeanPropertyRowMapper<Customer>(Customer.class));
	
	}
	//----------------------------------

	public List<Customer> view_all()
	{
		String sql="select * from Main007";
		
		List<Customer> cust=(List<Customer>) jdbcTemplate.query(sql, new BeanPropertyRowMapper<Customer>(Customer.class));
	    return cust;
	}
}